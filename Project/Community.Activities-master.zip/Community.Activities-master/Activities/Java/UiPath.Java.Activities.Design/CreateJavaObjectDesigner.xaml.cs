﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UiPath.Java.Activities.Design
{
    // Interaction logic for GetJavaObjectDesigner.xaml
    public partial class CreateJavaObjectDesigner
    {
        public CreateJavaObjectDesigner()
        {
            InitializeComponent();
        }
    }
}
