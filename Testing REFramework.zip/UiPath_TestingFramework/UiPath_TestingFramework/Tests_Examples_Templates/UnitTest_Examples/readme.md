### UnitTest_Examples ###

In this folder are examples of how Unit Tests can be structured.

NOTE: These are not actual unit tests as they are not invoking the workflow that are to be tested. Considered these examples as a simulation of unit tests for the teaching purposes.

Feel free to rename or remove this folder completely as it is not closely coupled with the Framework itself.