﻿namespace UiPath.FTP
{
    public enum FtpObjectType
    {
        Directory,
        File,
        Link
    }
}
