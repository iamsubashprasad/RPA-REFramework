﻿namespace UiPath.FTP.Properties
{
    internal class Resources : UiPath_FTP
    {
    }
}
