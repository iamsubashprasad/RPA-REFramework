### Test_Data ###

Test_Data folder should contain files that are used in functional tests (e.g. Configuration files, Input files like .json or .xml, etc.).

Feel free to rename or remove this folder completely as it is not closely coupled with the Framework itself.