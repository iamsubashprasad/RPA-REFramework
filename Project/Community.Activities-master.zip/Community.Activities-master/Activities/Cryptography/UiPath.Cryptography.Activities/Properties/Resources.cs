﻿namespace UiPath.Cryptography.Activities.Properties
{
    class Resources : UiPath_Cryptography_Activities
    {
    }
}
