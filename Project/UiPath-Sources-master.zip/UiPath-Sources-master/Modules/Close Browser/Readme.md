# Close Browser

Source File
closeBrowser.xaml

This File is used to close the browser