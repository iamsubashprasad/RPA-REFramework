﻿namespace UiPath.FTP.Activities.Design
{
    public partial class WithFtpSessionDesigner
    {
        public WithFtpSessionDesigner()
        {
            InitializeComponent();
        }
    }
}
