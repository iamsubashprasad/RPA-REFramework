﻿namespace UiPath.TestUtils
{
    public static class TestCategories
    {
        public const string Category = "Category";
        public const string LongRunning = "LongRunning";
        public const string Digitization = "Digitization";
        public const string ValidationStation = "ValidationStation";
    }
}
