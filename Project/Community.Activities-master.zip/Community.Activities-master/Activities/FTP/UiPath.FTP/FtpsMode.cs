﻿namespace UiPath.FTP
{
    public enum FtpsMode
    {
        Explicit = 1,
        Implicit = 2,
        None = 0
    }
}
