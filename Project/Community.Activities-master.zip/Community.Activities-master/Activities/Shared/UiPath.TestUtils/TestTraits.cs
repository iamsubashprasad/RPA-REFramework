﻿namespace UiPath.TestUtils
{
    public static class TestTraits
    {
        public const string Target = "Target";
    }
}
