﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UiPath.Java.Activities.Design.Properties
{
    class Resources : UiPath_Java_Activities_Design
    {
    }
}
