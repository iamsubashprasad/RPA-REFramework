﻿namespace UiPath.Script.Activities.Design
{
    // Interaction logic for ReadLineDesigner.xaml
    public partial class ScriptActivityDesigner
    {
        public ScriptActivityDesigner()
        {
            InitializeComponent();
        }
    }
}