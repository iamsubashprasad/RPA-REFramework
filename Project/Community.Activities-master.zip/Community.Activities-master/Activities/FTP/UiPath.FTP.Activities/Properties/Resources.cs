﻿namespace UiPath.FTP.Activities.Properties
{
    internal class Resources : UiPath_FTP_Activities
    {
    }
}
