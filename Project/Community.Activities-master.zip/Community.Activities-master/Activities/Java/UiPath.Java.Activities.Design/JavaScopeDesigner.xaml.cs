﻿
namespace UiPath.Java.Activities.Design
{
    // Interaction logic for JavaScopeDesigner.xaml
    public partial class JavaScopeDesigner
    {
        public JavaScopeDesigner()
        {
            InitializeComponent();
        }
    }
}
