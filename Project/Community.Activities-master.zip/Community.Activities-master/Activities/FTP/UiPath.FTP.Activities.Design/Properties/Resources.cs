﻿namespace UiPath.FTP.Activities.Design.Properties
{
    internal class Resources : UiPath_FTP_Activities_Design
    {
    }
}
