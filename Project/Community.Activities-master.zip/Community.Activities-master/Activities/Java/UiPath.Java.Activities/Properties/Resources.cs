﻿
namespace UiPath.Java.Activities.Properties
{
    internal class Resources : UiPath_Java_Activities
    {
    }
}
