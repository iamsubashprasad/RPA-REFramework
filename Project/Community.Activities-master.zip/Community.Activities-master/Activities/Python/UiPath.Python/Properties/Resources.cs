﻿namespace UiPath.Python.Properties
{
    internal class Resources : UiPath_Python
    {
    }
}
