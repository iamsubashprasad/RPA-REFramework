# whatsapp_auto_greetings
user must be logged into Web.whatsapp.com
works only for whatsapp accounts on android (not tested on iphone)
user must create a broadcast group (not whatsapp group) before using this workflow
