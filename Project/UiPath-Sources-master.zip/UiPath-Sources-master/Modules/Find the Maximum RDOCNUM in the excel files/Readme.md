## Find the Maximum RDOCNUM in the excel files

Get the maximum of RDOCNUM from Specific excel and list of excel files.

It takes two arguments
- folderPath
- date(optional) (Format for date is yyyymmdd i.e. 20170629 ) 

Output: 
- MaxRDOCNUM for that date as String value.


**If date is not supplied, it will return the max RDOCNUM for all the files in the folder mentioned.**
**Date Should be the prefix of the Excel file**