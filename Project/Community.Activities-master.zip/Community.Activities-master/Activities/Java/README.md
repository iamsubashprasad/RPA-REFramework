What you need ?
1. JDK 1.5 or UP: http://www.oracle.com/technetwork/java/javase/downloads/jdk10-downloads-4416644.html
2. Make sure you add path to java to your PATH Envionment variable. https://www.java.com/en/download/help/path.xml
3. Intellij or Eclipse to build the java part that invokes methods. https://www.jetbrains.com/idea/
4. To create a jar from the java invoker program in Intellij click Build->Build Artifcats->InvokeJava(middle of the screen)->Build
