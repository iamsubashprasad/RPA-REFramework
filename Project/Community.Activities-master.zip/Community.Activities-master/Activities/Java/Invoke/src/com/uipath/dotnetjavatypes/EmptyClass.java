package com.uipath.dotnetjavatypes;

public class EmptyClass {
}
