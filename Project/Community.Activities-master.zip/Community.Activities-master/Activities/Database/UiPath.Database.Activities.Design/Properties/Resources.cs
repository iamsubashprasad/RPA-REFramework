﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UiPath.Database.Activities.Design.Properties
{
    class Resources : UiPath_Database_Activities_Design
    {
    }
}
