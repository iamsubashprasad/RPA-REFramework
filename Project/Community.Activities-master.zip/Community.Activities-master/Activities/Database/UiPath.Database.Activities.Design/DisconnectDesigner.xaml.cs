﻿
namespace UiPath.Database.Activities.Design
{
    // Interaction logic for DisconnectDesigner.xaml
    public partial class DisconnectDesigner
    {
        public DisconnectDesigner()
        {
            InitializeComponent();
        }
    }
}
