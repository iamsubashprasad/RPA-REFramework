﻿namespace UiPath.Python.Activities.Design
{
    /// <summary>
    /// Interaction logic for PythonScopeDesigner.xaml
    /// </summary>
    public partial class PythonScopeDesigner
    {
        public PythonScopeDesigner()
        {
            InitializeComponent();
        }
    }
}
