﻿namespace UiPath.Python.Activities.Design.Properties
{
    internal class Resources : UiPath_Python_Activities_Design
    {
    }
}
