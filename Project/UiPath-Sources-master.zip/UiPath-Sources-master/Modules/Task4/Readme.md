# Zip Folder
Zip the folders and subfolders for the given folder path

# Task Schedular
Refer the document 