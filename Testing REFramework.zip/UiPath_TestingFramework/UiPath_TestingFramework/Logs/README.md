### Logs ###

Logs folder contains test log files created by runnning of Framework.

Log naming format is TestLog_yyyy-MM-dd.txt 

If in the moment of running more than 10 logs exist in Logs folder, oldest ones are deleted (this number can be changed from inside of the Framework).