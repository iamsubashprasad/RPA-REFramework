﻿
namespace UiPath.Java.Activities.Design
{
    // Interaction logic for ConvertJavaObjectDesigner.xaml
    public partial class ConvertJavaObjectDesigner
    {
        public ConvertJavaObjectDesigner()
        {
            InitializeComponent();
        }

        private void Expr_TargetUpdated(object sender, System.Windows.Data.DataTransferEventArgs e)
        {

        }

        private void Expr_SourceUpdated(object sender, System.Windows.Data.DataTransferEventArgs e)
        {

        }
    }
}
