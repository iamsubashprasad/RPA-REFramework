# Stock-Data-Retrieval
RPA UiPath


Firstly run the Stock Data Retrieval.xaml file using UiPath.

Click Ok and select the Stock App Reports directory.

Choose option whether to download individual, or bulk, or only visualize data.


Individual:
-----------
Select the company name listed, or add a new company with the company symbol.

The company last month stock data-set will be downloaded.

Now you are asked whether the data-set needs visualization or download other one.

Click on the respective option to get the image of the visualization.

Click Exit.


Bulk:
-----

The companies listed in the Company List.csv will be downloaded one by one.

It is saved in the Stock App Report Directory.

Visualisation:
--------------

The visualisation for the custom dataset can be done with this option.

For now, Line chart has been implemented for Open values of the Dataset.
