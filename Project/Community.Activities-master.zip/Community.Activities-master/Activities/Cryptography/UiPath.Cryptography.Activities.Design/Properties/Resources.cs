﻿namespace UiPath.Cryptography.Activities.Design.Properties
{
    public class Resources : UiPath_Cryptography_Activities_Design
    {
    }
}
