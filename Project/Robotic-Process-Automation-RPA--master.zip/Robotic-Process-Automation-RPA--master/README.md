# Robotic-Process-Automation-RPA-
Automation of desktop, web, mainframe and citrix based application using RPA tools such as BluePrism, PegaRobotics, Automaton Anywhere and UiPath.
These applications should be rule based, structured and manual.

Note - RPA tools are not available for free.

### Based on my limited experience with these tools and research, I have given important features and PROS / CONS for main industry standard tools (check attached doc).
