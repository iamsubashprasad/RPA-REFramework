﻿namespace UiPath.Cryptography.Properties
{
    class Resources : UiPath_Cryptography
    {
    }
}
