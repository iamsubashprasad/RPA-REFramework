﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UiPath.Database.Activities.Properties
{
    class Resources : UiPath_Database_Activities
    {
    }
}
