﻿namespace UiPath.Python.Activities.Properties
{
    internal class Resources : UiPath_Python_Activities
    {
    }
}
